package com.mycompany.libro;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @David Andres Inestroza Gonzales 202320010101 
 */
public class Libro {

    public String titulo;
    public String autor;
    public int anioPublicacion;
    public String genero;
    private boolean disponible;

    // Constructor para inicializar los atributos
    public Libro(String titulo, String autor, int anioPublicacion, String genero) {
        this.titulo = titulo;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
        this.genero = genero;
        this.disponible = true; // Por defecto, el libro está disponible
    }

    // Métodos para prestar y devolver el libro
    public void prestar() {
        if (disponible) {
            disponible = false;
            System.out.println("El libro '" + titulo + "' ha sido prestado.");
        } else {
            System.out.println("El libro '" + titulo + "' no está disponible.");
        }
    }

    public void devolver() {
        if (!disponible) {
            disponible = true;
            System.out.println("El libro '" + titulo + "' ha sido devuelto.");
        } else {
            System.out.println("El libro '" + titulo + "' ya está en la biblioteca.");
        }
    }

    // Método para mostrar información detallada del libro
    public String mostrarInfo() {
        return "Título: " + titulo + "\nAutor: " + autor + "\nAño de Publicación: " + anioPublicacion + 
               "\nGénero: " + genero + "\nDisponible: " + (disponible ? "Sí" : "No");
    }

    // Getters necesarios para buscar por título o autor
    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }
}

// La clase Biblioteca debe estar fuera de la clase Libro
class Biblioteca {
    public ArrayList<Libro> libros;

    public Biblioteca() {
        libros = new ArrayList<>();
    }

    // Método para agregar un libro
    public void agregarLibro(Libro libro) {
        libros.add(libro);
        System.out.println("Libro agregado: " + libro.getTitulo());
    }

    // Método para buscar libros por título o autor
    public void buscarLibro(String criterio) {
        boolean encontrado = false;
        for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(criterio) || libro.getAutor().equalsIgnoreCase(criterio)) {
                System.out.println(libro.mostrarInfo());
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontraron libros con el criterio: " + criterio);
        }
    }

    // Método para prestar un libro
    public void prestarLibro(String titulo) {
        for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                libro.prestar();
                return;
            }
        }
        System.out.println("No se encontró el libro con título: " + titulo);
    }

    // Método para devolver un libro
    public void devolverLibro(String titulo) {
        for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                libro.devolver();
                return;
            }
        }
        System.out.println("No se encontró el libro con título: " + titulo);
    }

    // Mostrar todos los libros disponibles
    public void mostrarLibrosDisponibles() {
        System.out.println("Libros disponibles:");
        for (Libro libro : libros) {
            if (libro.mostrarInfo().contains("Disponible: Sí")) {
                System.out.println(libro.mostrarInfo());
            }
        }
    }
public class Main {
    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();
        Scanner scanner = new Scanner(System.in);

        // Agregar algunos libros de prueba
        biblioteca.agregarLibro(new Libro("Cien años de soledad", "Gabriel García Márquez", 1967, "Novela"));
        biblioteca.agregarLibro(new Libro("1984", "George Orwell", 1949, "Distopía"));
        biblioteca.agregarLibro(new Libro("El principito", "Antoine de Saint-Exupéry", 1943, "Fábula"));

        // Menu para realizar operaciones
        int opcion;
        do {
            System.out.println("\n--- Biblioteca Virtual ---");
            System.out.println("1. Agregar libro");
            System.out.println("2. Buscar libro");
            System.out.println("3. Prestar libro");
            System.out.println("4. Devolver libro");
            System.out.println("5. Mostrar libros disponibles");
            System.out.println("6. Salir");
            System.out.print("Selecciona una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1 -> {
                    System.out.print("Título: ");
                    String titulo = scanner.nextLine();
                    System.out.print("Autor: ");
                    String autor = scanner.nextLine();
                    System.out.print("Año de publicación: ");
                    int anio = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Género: ");
                    String genero = scanner.nextLine();
                    biblioteca.agregarLibro(new Libro(titulo, autor, anio, genero));
                }
                case 2 -> {
                    System.out.print("Buscar por título o autor: ");
                    String criterio = scanner.nextLine();
                    biblioteca.buscarLibro(criterio);
                }
                case 3 -> {
                    System.out.print("Título del libro a prestar: ");
                    String tituloPrestar = scanner.nextLine();
                    biblioteca.prestarLibro(tituloPrestar);
                }
                case 4 -> {
                    System.out.print("Título del libro a devolver: ");
                    String tituloDevolver = scanner.nextLine();
                    biblioteca.devolverLibro(tituloDevolver);
                }
                case 5 -> biblioteca.mostrarLibrosDisponibles();
                case 6 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 6);
    }
}
}

